from . import IOBlueprint
from flask_socketio import emit

ws_blueprint = IOBlueprint('/ws')


@ws_blueprint.on('say')
def say():
    emit('flash', "Server says...", namespace='/')


@ws_blueprint.on('echo')
def echo(msg):
    emit('flash', msg.get('data'), namespace='/')


@ws_blueprint.on('my event')
def handle_my_custom_event(json):
    emit('connect response', 'hello client', namespace='/ws')
    print('received json: ' + str(json))