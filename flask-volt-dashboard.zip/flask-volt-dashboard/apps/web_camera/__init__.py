from flask import Blueprint

blueprint = Blueprint(
    'web_camera_blueprint',
    __name__,
    url_prefix='/web_camera'
)