from flask import render_template
from flask_login import login_required

from apps.web_camera import blueprint


# 화면
@blueprint.route("/realtime")
@login_required
def realtime():
    return render_template("web_camera/realtime.html")


# capture
@blueprint.route("/capture")
@login_required
def capture():
    return render_template("web_camera/capture.html")


# face detection
@blueprint.route("/face_detection")
@login_required
def face_detection():
    return render_template("web_camera/face_detection.html")