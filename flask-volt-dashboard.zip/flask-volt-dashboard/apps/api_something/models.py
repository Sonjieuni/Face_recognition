from apps import db
from datetime import datetime


class Something(db.Model):

    __tablename__ = "TB_SOMETHING"
    __table_args__ = {"mysql_collate": "utf8_general_ci"}

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    content = db.Column(db.Text())
    created_datetime = db.Column(db.DateTime(), default=datetime.now)
    updated_datetime = db.Column(db.DateTime(), default=datetime.now, onupdate=datetime.now())

    """
    def __repr__(self):
        return str(self.title)
    """

    def __repr__(self):
        return {"id": self.id, "title": self.title, "content": self.content,
                "created_datetime": self.created_datetime, "updated_datetime": self.updated_datetime}

    def as_dict(self):
        return {x.name: getattr(self, x.name) for x in self.__table__.columns}

