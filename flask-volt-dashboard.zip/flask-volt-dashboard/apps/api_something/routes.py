import base64
import os
import uuid

from apps.api_something import blueprint
from flask_restx import Resource, Api

api = Api(blueprint, version="1.0", title="OCR API", description="OCR API 예제")

from werkzeug.datastructures import FileStorage

upload_parser = api.parser()
upload_parser.add_argument('file', location='files', type=FileStorage, required=True)


# easyocr
@api.route("/easyocr")
@api.expect(upload_parser)
class EasyOcrApi(Resource):
    def post(self):
        """EasyOCR"""
        args = upload_parser.parse_args()
        file = args['file']  # This is FileStorage instance

        # OCR 처리할 이미지 임시 저장 위치
        ocr_temp_path = os.path.join(upload_dir, "ocr_temp_path")
        if not os.path.exists(ocr_temp_path):
            os.makedirs(ocr_temp_path)

        # 파일 저장
        new_filename = str(uuid.uuid4())
        file.save(os.path.join(ocr_temp_path, new_filename))

        # OCR 처리
        import easyocr
        reader = easyocr.Reader(["ko", "en"])
        ocr_results = reader.readtext(os.path.join(ocr_temp_path, new_filename))

        # 이미지 읽기
        import cv2
        import numpy as np
        img = cv2.imread(os.path.join(ocr_temp_path, new_filename))

        # 이미지 파일에 인식된 텍스트 표시하기
        for ocr in ocr_results:
            pts = np.array(ocr[0])
            cv2.polylines(img, [pts], True, (0, 0, 255), 2)

        # 이미지 파일을 base64로 인코딩
        img_jpg = cv2.imencode('.jpg', img)
        image_base64 = base64.b64encode(img_jpg[1]).decode('utf-8')

        # 파일 삭제
        os.remove(os.path.join(ocr_temp_path, new_filename))

        # 결과
        results = {"result": "ok", "ocr_results": ocr_results, 'image_base64': image_base64}

        return {'results': results}, 201

