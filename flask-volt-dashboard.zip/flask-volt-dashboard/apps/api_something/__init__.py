from flask import Blueprint

blueprint = Blueprint(
    'api_something_blueprint',
    __name__,
    url_prefix='/api_something'
)
